package com.SpringAnnotEx.SpringBook;

import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Book {
	
	int bcode;
	String bname;
	double price;
	List<String>cityList;
	Map<String, Double>sales;
	
	

	@Override
	public String toString() {
		return "Book [bcode=" + bcode + ", bname=" + bname + ", price=" + price + ", cityList=" + cityList + ", sales="
				+ sales + "]";
	}

	public int getBcode() {
		return bcode;
	}

	public void setBcode(int bcode) {
		this.bcode = bcode;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public List<String> getCityList() {
		return cityList;
	}

	public void setCityList(List<String> cityList) {
		this.cityList = cityList;
	}

	

	public Map<String, Double> getSales() {
		return sales;
	}

	public void setSales(Map<String, Double> sales) {
		this.sales = sales;
	}

	public Book(int bcode, String bname, double price, List<String> cityList, Map<String, Double> sales) {
		super();
		this.bcode = bcode;
		this.bname = bname;
		this.price = price;
		this.cityList = cityList;
		this.sales = sales;
	}

	Book(){
		
	}

		
	
	
	

}
