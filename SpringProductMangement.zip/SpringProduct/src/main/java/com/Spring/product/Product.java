package com.Spring.product;

import java.util.List;
import java.util.Map;

public class Product {
	
	int proId;
	String category;
	Description desc;
	List<String>chemicals;
	Map<String, Double>ChemicalQty;
	
	Product(){
		  
	}

	

	public Map<String, Double> getChemicalQty() {
		return ChemicalQty;
	}



	public void setChemicalQty(Map<String, Double> chemicalQty) {
		ChemicalQty = chemicalQty;
	}



	public Product(int proId, String category, Description desc, List<String> chemicals,
			Map<String, Double> chemicalQty) {
		super();
		this.proId = proId;
		this.category = category;
		this.desc = desc;
		this.chemicals = chemicals;
		ChemicalQty = chemicalQty;
	}



	public int getProId() {
		return proId;
	}

	public void setProId(int proId) {
		this.proId = proId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Description getDesc() {
		return desc;
	}

	public void setDesc(Description desc) {
		this.desc = desc;
	}

	public List<String> getChemicals() {
		return chemicals;
	}

	public void setChemicals(List<String> chemicals) {
		this.chemicals = chemicals;
	}



	@Override
	public String toString() {
		return "Product [proId=" + proId + ", category=" + category + ", desc=" + desc + ", chemicals=" + chemicals
				+ ", ChemicalQty=" + ChemicalQty + "]";
	}

	

		

}
