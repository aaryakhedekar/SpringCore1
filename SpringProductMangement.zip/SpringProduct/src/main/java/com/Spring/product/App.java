package com.Spring.product;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext con = new ClassPathXmlApplicationContext("beans.xml");
        
        
        Product p1 = (Product)con.getBean("p1");
        System.out.println(p1.toString()); 
        
//        Description d1 = p1.getDesc();
//        System.out.println(d1.toString());
        
    }
    
}
