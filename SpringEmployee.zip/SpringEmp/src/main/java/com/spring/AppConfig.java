package com.spring;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	
	@Bean(name="p1")
	public Project getProject() {
		Project p = new Project();
		
		p.setPid(2);
		p.setDuration("3.5 years");
		p.setCost(323560.55);
		
		return p;
	}
	
	@Bean(name="e1")
	public Employee getEmp() {
		
		Employee e = new Employee();
		e.setEmpId(102);
		e.setName("Ajay");
		e.setSalary(50000);
		Map<String, String>adr = new HashMap<String, String>();
		adr.put("xyz office", "xyz home");
		e.setAddress(adr);
		
		return e;
		
	}

}
