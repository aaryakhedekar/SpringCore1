package com.spring;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

public class Employee implements InitializingBean, DisposableBean{
	
	int empId;
	String name;
	double salary;
	Map<String, String>address;
	@Autowired
	Project p;
	
	Employee(){
		
	}

	public Project getP() {
		return p;
	}
	public void setP(Project p) {
		this.p = p;
	}
	public Employee(int empId, String name, double salary, Map<String, String> address, Project p) {
		super();
		this.empId = empId;
		this.name = name;
		this.salary = salary;
		this.address = address;
		this.p = p;
	}
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Map<String, String> getAddress() {
		return address;
	}

	public void setAddress(Map<String, String> address) {
		this.address = address;
	}



	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", salary=" + salary + ", address=" + address + ", p="
				+ p + "]";
	}



	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Destroying with DisposableBean...");
		
	}



	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Starting with InitializingBean..");
		
	}
	
	@PostConstruct
	void start() {
		System.out.println("Starting with @PostConstruct..");
	}
	
	@PreDestroy
	void end() {
		System.out.println("Ending with @PreDestroy..");
	}

	
	
	
	

}
